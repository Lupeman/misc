# Activity one.

The first task is to make the following responsive:
[Codepen](http://codepen.io/chriscoyier/pen/lDJmf)
The exercise should be completed purely in HTML/CSS. Feel free to use vanilla CSS, or the pre-processor of your choice (LESS, SASS etc).

This application was developed on OS X El Capitan Version 10.11.6.

## Technologies used:
  * HTML, CSS

## Possible Improvements

  * For consistency - would either add fourth secondary image or resize third image to cover entire width at smaller screen size.
